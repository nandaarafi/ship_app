package com.example.ship_apps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
